angular.module("controlBenchApp")
    .controller("informationController", function() {
        
    });
