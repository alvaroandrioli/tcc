'''
Created on 19 de abr de 2017

@author: andrioli
'''
from stateConstants import StateConstants

const = StateConstants()

const.setConstant('SERIAL.OPEN', False)
const.setConstant("SERIAL.CONNECTED", False)